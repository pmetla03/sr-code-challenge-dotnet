﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using challenge.Models;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;
using challenge.Data;
using Newtonsoft.Json;

namespace challenge.Repositories
{
    public class EmployeeRespository : IEmployeeRepository
    {
        private readonly EmployeeContext _employeeContext;
        private readonly ILogger<IEmployeeRepository> _logger;

        public EmployeeRespository(ILogger<IEmployeeRepository> logger, EmployeeContext employeeContext)
        {
            _employeeContext = employeeContext;
            _logger = logger;
        }

        public Employee Add(Employee employee)
        {
            employee.EmployeeId = Guid.NewGuid().ToString();
            _employeeContext.Employees.Add(employee);
            return employee;
        }

        public Employee GetById(string id)
        {
            var emp = _employeeContext.Employees.Include(d => d.DirectReports).FirstOrDefault(e => e.EmployeeId == id);
            
            emp.numberOfReports = emp.DirectReports != null ? emp.DirectReports.Count : 0;
            if (emp.DirectReports != null)
            {
                foreach(var e in emp.DirectReports)
                {
                    emp.numberOfReports += GetNumberOfReport(e.EmployeeId);
                }
            }
            return emp;
        }

        private int GetNumberOfReport(string id)
        {
            var emp = _employeeContext.Employees.Include(d => d.DirectReports).FirstOrDefault(x => x.EmployeeId == id);
            emp.numberOfReports = emp.DirectReports != null ? emp.DirectReports.Count : 0;
            if (emp.DirectReports != null)
            {
                foreach (var e in emp.DirectReports)
                {
                    int count = GetNumberOfReport(e.EmployeeId);
                }
            }
            return emp.DirectReports != null ? emp.DirectReports.Count : 0;
        }

        public Task SaveAsync()
        {
            return _employeeContext.SaveChangesAsync();
        }

        public Employee Remove(Employee employee)
        {
            return _employeeContext.Remove(employee).Entity;
        }
    }
}
